<center> AllHookInOne
------------------------
- A project contains all method hook approachs for android such as dalvik hook, art hook, elf hook and inline hook;
- Before buiding the project, please patch your NDK first, see [ndk-patch](https://github.com/boyliang/ndk-patch);
- Any questions, please connect me, and welcome to my blog [www.im-boy.net](http://www.im-boy.net)

** Updated at 2015.4.14 **
- Support android art hook for 4.4.x.

** Updated at 2014.10.27 **
- Add elf hook, and parsing elf dynamic library by executable view.
