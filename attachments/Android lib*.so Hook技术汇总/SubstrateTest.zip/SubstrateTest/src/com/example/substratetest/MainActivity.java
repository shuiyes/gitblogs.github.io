package com.example.substratetest;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {
	
	static{
		System.loadLibrary("ARM_PC");
		System.loadLibrary("ARM");
		System.loadLibrary("Thumb");
		System.loadLibrary("Thumb_PC");
		System.loadLibrary("doHook");
	}
	
	private Button btn;
	public native int ARMCALL();
	public native int ARMCALLPC();
	public native int ThumbCALL();
	public native int ThumbCALLPC();
	public native void doHook();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		btn = (Button) findViewById(R.id.test_btn);
		btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				ARMCALL();
				ARMCALLPC();
				ThumbCALL();
				Log.i("Ret", ThumbCALLPC() + "");
			}
		});
		doHook();
	}
	
}
