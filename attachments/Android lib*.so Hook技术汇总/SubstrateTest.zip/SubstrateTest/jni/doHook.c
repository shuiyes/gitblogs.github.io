#include <jni.h>
#include <android/log.h>
#include <stdio.h>
#include <dlfcn.h>

#define LOG_TAG "ThomasKing"
#define LOGD(fmt, args...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, fmt, ##args)

/*
char *hook_fun[] = {
	"Java_com_example_substratetest_MainActivity_ARMCALLPC",
	"Java_com_example_substratetest_MainActivity_ARMCALL",
	"Java_com_example_substratetest_MainActivity_ThumbCALL",
	"Java_com_example_substratetest_MainActivity_ThumbCALLPC"
};
*/

char *hook_fun[] = {
	"TK_puts",
	"Java_com_example_substratetest_MainActivity_ARMCALL",
	"Java_com_example_substratetest_MainActivity_ThumbCALL",
	"TK_puts"
};

char *hook_so[] = {
	"libARM_PC.so",
	"libARM.so",
	"libThumb.so",
	"libThumb_PC.so"
};

void *old_fun[4];

void added_fun0(void *p1, void *p2){
	LOGD("Hook_fun");
	((void(*)())old_fun[0])();
}

void added_fun1(JNIEnv *env, jobject obj){
	LOGD("Hook_fun");
	((void(*)(JNIEnv *, jobject))old_fun[1])(env, obj);
}

void added_fun2(JNIEnv *env, jobject obj){
	LOGD("Hook_fun");
	((void(*)(JNIEnv *, jobject))old_fun[2])(env, obj);
}

void added_fun3(void *p1, void *p2){
	LOGD("Hook_fun");
	((void(*)())old_fun[3])();
}

void HookAll(){
	int i;
	void *handle;
	void *fun;
	void *new_fun[4];

	new_fun[0] = (void*)added_fun0;
	new_fun[1] = (void*)added_fun1;
	new_fun[2] = (void*)added_fun2;
	new_fun[3] = (void*)added_fun3;

	for(i=0;i<4;i++){
		handle = dlopen(hook_so[i], RTLD_NOW);
		if(handle == NULL){
			LOGD("dlopen so[%s] failed", hook_so[i]);
			break;
		}
		fun = dlsym(handle, hook_fun[i]);
		if(fun == NULL){
			LOGD("dlsym fun[%s] failed", hook_fun[i]);
			break;
		}
		MSHookFunction(fun, new_fun[i], old_fun + i);
	}
}

JNIEXPORT void JNICALL Java_com_example_substratetest_MainActivity_doHook(JNIEnv *env, jobject obj){
	void *handle;
	void *fun;
	LOGD("Start");
//	handle = dlopen("libsubstrate.so", RTLD_NOW);
	handle = dlopen("libTKHooklib.so", RTLD_NOW);
	if(handle == NULL){
		LOGD("dlopen [%s]", dlerror());
		return ;
	}
//	MSHookFunction = dlsym(handle, "MSHookFunction");
	MSHookFunction = dlsym(handle, "TK_InlineHookFunction");
	if(MSHookFunction == NULL){
		LOGD("dlopen [%s]", dlerror());
		return ;
	}
	HookAll();
	LOGD("End");
}
