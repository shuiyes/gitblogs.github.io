#include <jni.h>
#include <android/log.h>
#include <stdio.h>

#define LOG_TAG "ThomasKing"
#define LOGD(fmt, args...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, fmt, ##args)

unsigned a, b, c;

void do_puts(){
	puts("ARM_PC_CALL");
}

void TK_puts(){
	puts("ARM_PC_CALL");
//	do_puts();
//	c = a + b;
}

JNIEXPORT jint JNICALL Java_com_example_substratetest_MainActivity_ARMCALLPC(JNIEnv *env, jobject obj){
//	freopen("/data/local/tmp/AP.txt", "a+", stdout);
	a = (unsigned) env;
	b = (unsigned) obj;
	TK_puts();
//	freopen("/data/local/tmp/stdout.txt", "a+", stdout);
	if(c)
		return c;
	else
		return 0;
}
