#include <jni.h>
#include <android/log.h>
#include <stdio.h>

#define LOG_TAG "ThomasKing"
#define LOGD(fmt, args...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, fmt, ##args)

void TK_puts(){
	puts("ARM_CALL");
}

JNIEXPORT jint JNICALL Java_com_example_substratetest_MainActivity_ARMCALL(JNIEnv *env, jobject obj){
	unsigned a, b;
	a = (unsigned) env;
	b = (unsigned) obj;
	a = a + b;
	b = a - b;
	a = a - b;
//	freopen("/data/local/tmp/A.txt", "a+", stdout);
	TK_puts();
	return (a * b)%1024;
}
