#include <jni.h>
#include <android/log.h>
#include <stdio.h>

#define LOG_TAG "ThomasKing"
#define LOGD(fmt, args...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, fmt, ##args)

unsigned a, b, c;

void do_puts(){
	puts("Thumb_PC_CALL");
}

void TK_puts(){
	puts("Thumb_PC_CALL");
	do_puts();
	c = 100;
}

JNIEXPORT jint JNICALL Java_com_example_substratetest_MainActivity_ThumbCALLPC(JNIEnv *env, jobject obj){
//	freopen("/data/local/tmp/TP.txt", "a+", stdout);
	a = (unsigned) env;
	b = (unsigned) obj;
	TK_puts();
	if(c)
		return c;
	else
		return 0;
}
